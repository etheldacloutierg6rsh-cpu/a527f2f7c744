// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("spdx sbom\n", stdout);
  return lionss_run_workload("spdx-sbom");
}
