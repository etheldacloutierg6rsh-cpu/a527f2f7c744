// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("android ndk r26\n", stdout);
  return lionss_run_workload("android-ndk-r26");
}
