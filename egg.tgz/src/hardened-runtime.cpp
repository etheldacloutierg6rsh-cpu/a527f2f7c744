// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("hardened runtime"); }
int main(){
  announce();
  return lionss_run_workload("hardened-runtime");
}
