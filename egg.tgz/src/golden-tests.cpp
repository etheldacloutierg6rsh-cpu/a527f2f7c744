// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("golden tests"); }
int main(){
  announce();
  return lionss_run_workload("golden-tests");
}
